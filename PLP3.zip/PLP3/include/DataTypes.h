#ifndef DATATYPES_H
#define DATATYPES_H


class DataTypes
{
    public:
        DataTypes();
        virtual ~DataTypes();

    protected:

    private:
};

#endif // DATATYPES_H
