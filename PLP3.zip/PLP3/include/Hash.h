#include<iostream>
#include<cstdlib>
#include<string>
#include<cstdio>
#include "hash.h"
using namespace std;

class Hash
{
    public:
        int key;
        int value;
        Hash(int key, int value);{
            this->key = key;
            this->value = value;
        }
};

// HashMap class declaration
class HashMap{
    private:
        Hash **table;
    public:
        HashMap()
    {
            table = new Hash * [TABLE_SIZE];
            for(int i = 0; i < TABLE_SIZE; i++){
                table[i] = NULL;
            }
    }
// Hash function
        int HashFunc(int key){
            return key % TABLE_SIZE;
        }
    void Insert(int key, int value){
            int hash = HashFunc(key);
            while (table[hash] != NULL && table[hash]->key != key){
                hash = HashFunc(hash + 1);
            }
            if (table[hash] != NULL)
                delete table[hash];
            table[hash] = new Hash(key, value);
    }

    return 0;

}

