#include <iostream>
#include <string>
#include <cmath>
#include <list>
#include <iterator>
#include <vector>
#include <map>
#include <cstdio>

using namespace std;

void showlist(list <int> g) // list iterator
{
    list <int> :: iterator it;
    for(it = g.begin(); it != g.end(); ++it)
        cout << '\t' << *it;
    cout << '\n';
}

int main(){

// int variable
int age = 20;
cout << "Int variable:" << endl;
cout << age << endl;
cout << "\n" << endl;

// string variable
string name = "Shyan";
printf("String variable (name):  %s", name.c_str());
cout << "\n" << endl;

// double variable
double inches = 9.5;
cout << "\nFloating-point number variable (inches): " << inches << endl;
cout << "\n" << endl;

// boolean variable
bool isWinner = false;
cout << "Boolean result (1=true, 0=false):" << endl;
cout << isWinner << endl;
cout << "\n" << endl;

// array
int favNums[] = {3,7,21,69,100};
size_t n = sizeof(favNums)/sizeof(favNums[0]);

cout << "Array of favorite numbers:" << endl;

for(size_t i = 0; i < n; i++){
    std::cout << favNums[i] << ' ';
}

cout << "\n" << endl;

// list
list <int> gqlist1, gqlist2;


for (int i = 0; i < 10; ++i)
{
    gqlist1.push_back(i * 2);
    gqlist2.push_front(i * 3);
}
cout << "\nA list of ints:\n";
showlist(gqlist1);
cout << "\n" << endl;

// Hash/Dictionary
std::map<int, std::string> name_map;
name_map[1] = "Chad"; // we will assign value to this key which is 1
name_map[2] = "Sarah";
name_map[3] = "Monica";
name_map[4] = "Brad";
name_map[5] = "Cooper";
cout << "Here is the name assigned to key 5:" << endl;
std::cout << name_map[5] << std::endl;

//sum of ints + floats
int sum = age + inches;
cout << "\nThe sum of an int and a float:" << endl;
cout << sum << endl;
cout << "It returns an int (narrowing conversion)." << endl;
return 0;
}
