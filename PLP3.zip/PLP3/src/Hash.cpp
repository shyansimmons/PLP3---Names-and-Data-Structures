#include "Hash.h"

Hash::Hash()
{
    //ctor
}

Hash::~Hash()
{
    //dtor
}
